function addToCart(productName) {
    alert(`${productName}をカートに追加しました！`);
}
